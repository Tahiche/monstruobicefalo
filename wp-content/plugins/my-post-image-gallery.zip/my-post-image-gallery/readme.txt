=== Plugin Name ===
Contributors: grx3
Donate link: http://hawkenterprises.org/post-image-gallery
Tags: post images, gallery, image gallery, post gallery, post image gallery
Requires at least: 2.0.2
Tested up to: 2.1
Stable tag: 4.3

Grabs source for all images posts and display's them. This looks for <img src=""> tag thus bypasses post thumbs and wordpress

== Description ==

Unlike any gallery I could find, this goes through your post content parsing out images and builds a gallery to be display anywhere. It has widget, tooltip descriptions, caching, resizing on fly, caching on the file or manual, all options are changable via nice control panel in the settings.
Features
Caching
JQuery Tooltips
Image Thumbnailing on the Fly
Cache Building Manual
Number of Images
Number of Post Searched
404 checking
An example is on
The Food Review

The images at the top are random, tool tip, and linked back to the posts.

== Installation ==

1. Upload and Active Plugin
2. Go to Settings > Post Image Gallery Options
3. include &lt;?php post_image_gallery() ?&gt; where you want the gallery
4. Enjoy!


== Frequently Asked Questions ==

= Why another gallery? =

= Honestly I couldn't find a plugin that pulled images from post content, I have
many sites that need that feature =

= How do I manually build cache?

= use the ?build=1 parameter on your site, that will force a 1000 posts at a time to be looked
through


== Screenshots ==


== Changelog ==

= 1.0 =
First Release

